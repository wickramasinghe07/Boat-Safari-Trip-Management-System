<div class="fotter">	
	 <div class="container">
		 <div class="fotter-grids">
			 <div class="col-md-4 fotter-left">
			 <p style="text-align:justify"></p>
			 </div>
			 <div class="col-md-4 fotter-middle">
				 <h3></h3>
				 <div class="footer-list">
						<h3></h3>
                        <div class="footer-list">
                        </div>
             
			     </div>
			 <div class="col-md-4 fotter-right" style="padding-left:10px">
			 <h3></h3><br/>
              <div class="footer-list">
			  </div></div>
			 <div class="social-icons">
			 <a href="#"><span class="facebook"> </span></a>
			 <a href="#"><span class="twitter"> </span></a>
			 <a href="#"><span class="googleplus"> </span></a>
			 <a href="#"><span class="pinterest"> </span></a>
			 <a href="#"><span class="instagram"> </span></a>
			 </div>
			 <div class="clearfix"></div>
	     </div>
		 <div class="clearfix"></div>
	 </div>
</div>
</div>  
<div class="copyright text-right">
<p style="padding-right:100px"></p>
</div>
  
  